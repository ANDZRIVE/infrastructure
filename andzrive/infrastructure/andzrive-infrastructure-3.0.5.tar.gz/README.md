# Ansible Collection - andzrive.infrastructure

This collection provides: 

    Creates 1 new user and Group "DevOps". 

    Creates 5 t2.micro Instances with ami-074cce78125f09d61 image on a board. 

    Provides complite installation of Wordpress engine to Ubutu servers. 

    Provides installation of R1soft agent.

Thank You for choosing our collection. 



Copyright © 2021 EvolveCyber juniors Team.



